(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__error_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__error_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__6528c5._.js",
    "static/chunks/bcd8d_react-dom_7b3e0c._.js",
    "static/chunks/node_modules__pnpm_4744b4._.js",
    "static/chunks/[root of the server]__2e1cf5._.js"
  ],
  "source": "entry"
});
