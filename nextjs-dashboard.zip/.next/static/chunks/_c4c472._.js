(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_c4c472._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_c4c472._.js",
  "chunks": [
    "static/chunks/65a4b_next_dist_compiled_react-dom_cabb1e._.js",
    "static/chunks/65a4b_next_dist_compiled_03ecd9._.js",
    "static/chunks/65a4b_next_dist_client_6f0a59._.js",
    "static/chunks/65a4b_next_dist_7dddfd._.js",
    "static/chunks/90823_@swc_helpers_cjs_6ab2e1._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f831d0._.js"
  ],
  "source": "entry"
});
