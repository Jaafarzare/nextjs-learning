(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_906bf1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_906bf1._.js",
  "chunks": [
    "static/chunks/[root of the server]__e1f01b._.css",
    "static/chunks/_a3a68e._.js"
  ],
  "source": "dynamic"
});
