(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_39bd12._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_39bd12._.js",
  "chunks": [
    "static/chunks/_a3a68e._.js",
    "static/chunks/app_ui_home_module_6dd21e.css"
  ],
  "source": "dynamic"
});
