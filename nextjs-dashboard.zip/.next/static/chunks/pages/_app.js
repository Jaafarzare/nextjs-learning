__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__e05ad1._.js",
  "static/chunks/bcd8d_react-dom_7b3e0c._.js",
  "static/chunks/node_modules__pnpm_4744b4._.js",
  "static/chunks/[root of the server]__f265a1._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_163cc2._.js"
])
