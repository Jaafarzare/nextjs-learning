(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_dbc324._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_dbc324._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_227123._.js",
    "static/chunks/app_b0570c._.js"
  ],
  "source": "dynamic"
});
