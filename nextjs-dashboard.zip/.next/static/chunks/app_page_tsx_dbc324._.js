(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_dbc324._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_dbc324._.js",
  "chunks": [
    "static/chunks/65a4b_next_dist_2f4fba._.js",
    "static/chunks/app_page_tsx_9fdd4f._.js",
    "static/chunks/app_ui_home_module_6dd21e.css"
  ],
  "source": "dynamic"
});
